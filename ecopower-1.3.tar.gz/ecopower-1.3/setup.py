import pathlib
from distutils.core import setup
import setuptools
HERE = pathlib.Path(__file__).parent
README = (HERE / "README.md").read_text()
setup(
  name = 'ecopower',
  packages = ['ecopower'],
  version = '1.3',
  license='MIT',
  description = 'This library allows you to efficiently use the hardware power of network devices.',
  long_description=README,
  long_description_content_type="text/markdown",
  author = 'Kroschu IT',
  author_email = 'kroschu.it@gmail.com',
  url = 'https://www.kromberg-schubert.de/',
  keywords = ['ecopower'],
  install_requires=[
      ],
  classifiers=[
    'License :: OSI Approved :: MIT License',
    'Programming Language :: Python :: 3',
  ],
)
